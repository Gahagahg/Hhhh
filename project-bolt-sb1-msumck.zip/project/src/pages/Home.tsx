import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, ShoppingBag } from 'lucide-react';

export default function Home() {
  return (
    <div className="pt-16">
      {/* Hero Section */}
      <div className="relative h-[600px]">
        <div className="absolute inset-0">
          <div className="w-full h-full">
            <img
              src="https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80"
              alt="Food background"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-50" />
          </div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl md:text-6xl">
              <span className="block">Delivery com</span>
              <span className="block text-red-600">50% OFF</span>
            </h1>
            <p className="mt-6 max-w-lg mx-auto text-xl text-white">
              Em pedidos acima de R$100, você paga apenas metade do valor total!
            </p>
            <div className="mt-10 flex justify-center gap-4">
              <Link
                to="/order"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
              >
                <ShoppingBag className="mr-2" /> Fazer Pedido
              </Link>
              <a
                href="https://wa.me/5551993092710"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-red-600 bg-white hover:bg-gray-50"
              >
                <Phone className="mr-2" /> Chamar no WhatsApp
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Como Funciona Section */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl font-extrabold text-gray-900">Como Funciona</h2>
            <p className="mt-4 text-lg text-gray-600">
              É simples! Faça seu pedido acima de R$100 e ganhe 50% de desconto no valor total.
            </p>
          </div>

          <div className="mt-12">
            <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-red-600 text-2xl font-bold mb-4">1</div>
                <h3 className="text-lg font-medium text-gray-900">Faça seu pedido</h3>
                <p className="mt-2 text-gray-600">
                  Escolha seus pratos favoritos até atingir R$100 ou mais
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-red-600 text-2xl font-bold mb-4">2</div>
                <h3 className="text-lg font-medium text-gray-900">Confirme seu endereço</h3>
                <p className="mt-2 text-gray-600">
                  Informe seu endereço completo para entrega
                </p>
              </div>

              <div className="bg-white p-6 rounded-lg shadow-lg">
                <div className="text-red-600 text-2xl font-bold mb-4">3</div>
                <h3 className="text-lg font-medium text-gray-900">Pague menos</h3>
                <p className="mt-2 text-gray-600">
                  Receba seu pedido pagando apenas 50% do valor total
                </p>
              </div>
            </div>
          </div>

          <div className="mt-12 bg-red-50 p-6 rounded-lg">
            <h3 className="text-xl font-bold text-red-600 mb-4">Exemplo de Economia:</h3>
            <p className="text-gray-800">
              Pedido: R$200 + Frete: R$10 = Total: R$210<br />
              Com nosso desconto você paga apenas: R$105
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}