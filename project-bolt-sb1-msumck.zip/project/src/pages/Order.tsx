import React, { useState } from 'react';
import { mainDishes } from '../data/menu';

export default function Order() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    mainDish: '',
    extras: [],
    observation: '',
    address: {
      cep: '',
      street: '',
      number: '',
      complement: '',
      neighborhood: '',
      city: '',
      reference: '',
      type: 'house'
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Format message for WhatsApp
    const message = `Novo Pedido!\n
Nome: ${formData.name}\n
Telefone: ${formData.phone}\n
Pedido: ${formData.mainDish}\n
Extras: ${formData.extras.join(', ')}\n
Observações: ${formData.observation}\n
Endereço: ${formData.address.street}, ${formData.address.number}\n
${formData.address.complement}\n
${formData.address.neighborhood} - ${formData.address.city}\n
CEP: ${formData.address.cep}\n
Referência: ${formData.address.reference}`;

    window.open(`https://wa.me/5511999999999?text=${encodeURIComponent(message)}`);
  };

  return (
    <div className="pt-20 pb-12 bg-gray-50">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Fazer Pedido</h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Personal Info */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Dados Pessoais</h3>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nome</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Telefone</label>
                  <input
                    type="tel"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.phone}
                    onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  />
                </div>
              </div>
            </div>

            {/* Order Details */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Pedido</h3>
              <div>
                <label className="block text-sm font-medium text-gray-700">Lanche Principal</label>
                <select
                  required
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  value={formData.mainDish}
                  onChange={(e) => setFormData({...formData, mainDish: e.target.value})}
                >
                  <option value="">Selecione um lanche</option>
                  {mainDishes.map((dish) => (
                    <option key={dish} value={dish}>{dish}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Extras</label>
                <div className="mt-2 grid grid-cols-2 gap-2">
                  {['Coca-Cola', 'Guaraná', 'Fanta', 'Sprite', 'Maionese', 'Ketchup', 'Mostarda', 'Batata Frita'].map((extra) => (
                    <label key={extra} className="inline-flex items-center">
                      <input
                        type="checkbox"
                        className="rounded border-gray-300 text-red-600 focus:ring-red-500"
                        value={extra}
                        checked={formData.extras.includes(extra)}
                        onChange={(e) => {
                          const newExtras = e.target.checked
                            ? [...formData.extras, extra]
                            : formData.extras.filter(item => item !== extra);
                          setFormData({...formData, extras: newExtras});
                        }}
                      />
                      <span className="ml-2 text-sm text-gray-700">{extra}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Observações</label>
                <textarea
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  rows={3}
                  value={formData.observation}
                  onChange={(e) => setFormData({...formData, observation: e.target.value})}
                  placeholder="Ex: Sem cebola, sem tomate..."
                />
              </div>
            </div>

            {/* Address */}
            <div className="space-y-4">
              <h3 className="text-lg font-medium text-gray-900">Endereço</h3>
              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-sm font-medium text-gray-700">CEP</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.cep}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, cep: e.target.value}
                    })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Tipo</label>
                  <select
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.type}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, type: e.target.value}
                    })}
                  >
                    <option value="house">Casa</option>
                    <option value="apartment">Apartamento</option>
                  </select>
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700">Rua</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.street}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, street: e.target.value}
                    })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Número</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.number}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, number: e.target.value}
                    })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Complemento</label>
                  <input
                    type="text"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.complement}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, complement: e.target.value}
                    })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Bairro</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.neighborhood}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, neighborhood: e.target.value}
                    })}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Cidade</label>
                  <input
                    type="text"
                    required
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.city}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, city: e.target.value}
                    })}
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-gray-700">Ponto de Referência</label>
                  <input
                    type="text"
                    className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                    value={formData.address.reference}
                    onChange={(e) => setFormData({
                      ...formData,
                      address: {...formData.address, reference: e.target.value}
                    })}
                  />
                </div>
              </div>
            </div>

            <div className="pt-4">
              <button
                type="submit"
                className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Enviar Pedido
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}