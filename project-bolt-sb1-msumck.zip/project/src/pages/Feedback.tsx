import React, { useState } from 'react';
import { Star } from 'lucide-react';

const feedbacks = [
  {
    id: 1,
    name: "Maria Silva",
    rating: 5,
    comment: "Melhor delivery que já usei! O desconto de 50% é real e a comida chegou quentinha.",
    image: "https://images.unsplash.com/photo-1494790108377-be9c29b29330",
    orderImage: "https://images.unsplash.com/photo-1513104890138-7c749659a591"
  },
  {
    id: 2,
    name: "João Santos",
    rating: 5,
    comment: "Incrível! Economizei R$100 no meu pedido e a qualidade é excelente.",
    image: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e",
    orderImage: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd"
  },
  {
    id: 3,
    name: "Ana Oliveira",
    rating: 5,
    comment: "Super recomendo! Entrega rápida e atendimento nota 10.",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80",
    orderImage: "https://images.unsplash.com/photo-1525518392674-39ba1febe881"
  }
];

export default function Feedback() {
  const [newFeedback, setNewFeedback] = useState({
    rating: 5,
    comment: '',
    image: null as File | null
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle feedback submission
    console.log('Feedback submitted:', newFeedback);
  };

  return (
    <div className="pt-16 pb-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900">
            Feedback dos Nossos Clientes
          </h2>
          <p className="mt-4 text-lg text-gray-600">
            Veja o que nossos clientes estão dizendo sobre nós
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {feedbacks.map((feedback) => (
            <div key={feedback.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
              <div className="p-6">
                <div className="flex items-center">
                  <img
                    className="h-12 w-12 rounded-full object-cover"
                    src={feedback.image}
                    alt={feedback.name}
                  />
                  <div className="ml-4">
                    <h3 className="text-lg font-medium text-gray-900">{feedback.name}</h3>
                    <div className="flex items-center">
                      {[...Array(feedback.rating)].map((_, i) => (
                        <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="mt-4 text-gray-600">{feedback.comment}</p>
                <img
                  src={feedback.orderImage}
                  alt="Pedido"
                  className="mt-4 w-full h-48 object-cover rounded-md"
                />
              </div>
            </div>
          ))}
        </div>

        {/* New Feedback Form */}
        <div className="mt-16">
          <div className="bg-white rounded-lg shadow-lg p-6">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">Deixe seu Feedback</h3>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700">Avaliação</label>
                <div className="mt-1 flex items-center">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button
                      key={star}
                      type="button"
                      className={`${
                        newFeedback.rating >= star ? 'text-yellow-400' : 'text-gray-300'
                      } hover:text-yellow-400`}
                      onClick={() => setNewFeedback({...newFeedback, rating: star})}
                    >
                      <Star className="h-8 w-8 fill-current" />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Comentário</label>
                <textarea
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-red-500 focus:ring-red-500"
                  rows={4}
                  value={newFeedback.comment}
                  onChange={(e) => setNewFeedback({...newFeedback, comment: e.target.value})}
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Foto do seu pedido</label>
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => setNewFeedback({
                    ...newFeedback,
                    image: e.target.files ? e.target.files[0] : null
                  })}
                  className="mt-1 block w-full text-sm text-gray-500
                    file:mr-4 file:py-2 file:px-4
                    file:rounded-md file:border-0
                    file:text-sm file:font-semibold
                    file:bg-red-50 file:text-red-600
                    hover:file:bg-red-100"
                />
              </div>

              <button
                type="submit"
                className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                Enviar Feedback
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}