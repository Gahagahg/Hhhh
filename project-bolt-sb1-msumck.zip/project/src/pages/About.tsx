import React from 'react';
import { Truck, Clock, DollarSign } from 'lucide-react';

export default function About() {
  return (
    <div className="pt-16">
      <div className="bg-red-600">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:py-24 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-base font-semibold text-white uppercase tracking-wide">Sobre Nós</h2>
            <p className="mt-1 text-4xl font-extrabold text-white sm:text-5xl sm:tracking-tight lg:text-6xl">
              DeliveryPlus
            </p>
            <p className="max-w-xl mt-5 mx-auto text-xl text-white">
              Entregando qualidade e economia para você
            </p>
          </div>
        </div>
      </div>

      <div className="bg-white">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">Nossa História</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Revolucionando o delivery de comida
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
              Nascemos com a missão de tornar a comida delivery mais acessível, mantendo a qualidade que você merece.
            </p>
          </div>

          <div className="mt-20">
            <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
              <div className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-red-600 text-white">
                    <Truck className="h-6 w-6" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900">Entrega Rápida</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-500">
                  Entregamos seu pedido com rapidez e segurança, mantendo a qualidade dos alimentos.
                </dd>
              </div>

              <div className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-red-600 text-white">
                    <Clock className="h-6 w-6" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900">Atendimento 24/7</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-500">
                  Estamos sempre disponíveis para atender seu pedido, 24 horas por dia, 7 dias por semana.
                </dd>
              </div>

              <div className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-red-600 text-white">
                    <DollarSign className="h-6 w-6" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900">Melhor Custo-Benefício</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-500">
                  50% de desconto em pedidos acima de R$100, incluindo o frete!
                </dd>
              </div>
            </dl>
          </div>
        </div>
      </div>

      <div className="bg-gray-50">
        <div className="max-w-7xl mx-auto py-16 px-4 sm:px-6 lg:px-8">
          <div className="lg:text-center">
            <h2 className="text-base text-red-600 font-semibold tracking-wide uppercase">Como Trabalhamos</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
              Processo Simples e Transparente
            </p>
          </div>

          <div className="mt-10">
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <div className="text-center">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">
                    Promoção 50% OFF
                  </h3>
                  <div className="mt-2 text-sm text-gray-500">
                    <p>Em todos os pedidos acima de R$100</p>
                    <p className="mt-4 font-semibold">Como funciona:</p>
                    <ul className="mt-2 list-disc list-inside">
                      <li>Faça seu pedido normalmente</li>
                      <li>Se o valor total (pedido + frete) ultrapassar R$100</li>
                      <li>Automaticamente você paga apenas 50% do valor total</li>
                      <li>Exemplo: Pedido R$200 + Frete R$10 = R$210</li>
                      <li>Você paga apenas: R$105</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}