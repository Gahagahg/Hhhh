export const mainDishes = [
  "X-Burger",
  "X-Salada",
  "X-Bacon",
  "X-Tudo",
  "X-Frango",
  "X-Calabresa",
  "Hot Dog Simples",
  "Hot Dog Completo",
  "Hot Dog Especial",
  "Batata Frita P",
  "Batata Frita M",
  "Batata Frita G",
  "Porção de Calabresa",
  "Porção de Frango",
  "Porção Mista"
];